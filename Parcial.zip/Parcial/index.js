const WebSocket = require("ws");
const express = require("express");
const http = require("http");

// ============================================================
// CONFIGURACIÓN E IDENTIDAD
// ============================================================
const [, , PORT_ARG, NGROK_URL] = process.argv;
const PORT = parseInt(PORT_ARG) || 3000;
const MY_URL = NGROK_URL || `ws://localhost:${PORT}`;
const MY_ID = "coordinator-darwin-55221510";
const MY_PRIORITY = Math.floor(Math.random() * 9000) + 1000;

// Tiempos de la rúbrica
const PING_INTERVAL = 2000;
const PING_RETRIES  = 3;
const PULSE_TIMEOUT = 8000;
const PULSE_CHECK   = 3000;

// ============================================================
// ESTADO GLOBAL
// ============================================================
let peers   = {}; // { id: { id, url, ws, lastPong, missedPings } }
let workers = {}; // { id: { id, url, capabilities, custom_tasks, lastPulse, load, ws } }
let leader  = null; // { id, url, priority }
let tasks   = {}; // { taskId: { ... } }

const app    = express();
app.use(express.json());
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

// ============================================================
// HELPERS DE COMUNICACIÓN
// ============================================================
function safeparse(msg) { try { return JSON.parse(msg.toString()); } catch { return null; } }

function send(ws, type, data) {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type, data }));
    }
}

function isLeader() { return leader !== null && leader.id === MY_ID; }

function log(msg) {
    const t = new Date().toISOString().slice(11, 19);
    console.log(`[${t}] ${msg}`);
}

// Sincroniza la lista de workers con los backups (Punto 6 de la rúbrica: Failover)
function broadcastWorkers() {
    if (!isLeader()) return;
    const workerList = Object.values(workers).map(w => ({
        id: w.id, url: w.url, capabilities: w.capabilities, custom_tasks: w.custom_tasks
    }));
    Object.values(peers).forEach(p => send(p.ws, "sync-workers", { workers: workerList }));
}

// ============================================================
// LÓGICA DE COORDINADORES (PEERS)
// ============================================================
function connectToPeer(id, url) {
    if (id === MY_ID || (peers[id] && peers[id].ws?.readyState === WebSocket.OPEN)) return;

    log(`Conectando a peer ${id} @ ${url}`);
    let ws;
    try { ws = new WebSocket(url); } catch (e) { return; }

    ws.on("open", () => {
        peers[id] = { id, url, ws, lastPong: Date.now(), missedPings: 0 };
        send(ws, "hello", { id: MY_ID, url: MY_URL });
    });

    ws.on("message", (msg) => {
        const parsed = safeparse(msg);
        if (!parsed) return;
        const { type, data } = parsed;
        
        switch (type) {
            case "welcome": handleWelcome(data); break;
            case "ping": send(ws, "pong", { id: MY_ID }); break;
            case "pong": if (peers[id]) { peers[id].lastPong = Date.now(); peers[id].missedPings = 0; } break;
            case "leader-announce": handleLeaderAnnounce(data, id); break;
            case "sync-workers": handleSyncWorkers(data); break;
        }
    });

    ws.on("close", () => {
        log(`Conexión con peer ${id} cerrada.`);
        if (leader && leader.id === id) { 
            log("Líder caído. Iniciando elección...");
            leader = null; 
            announceMyself(); 
        }
        delete peers[id];
    });
}

// ============================================================
// SERVIDOR WS (MENSAJES ENTRANTES)
// ============================================================
wss.on("connection", (ws) => {
    let connId = null;
    ws.on("message", (msg) => {
        const parsed = safeparse(msg);
        if (!parsed) return;
        const { type, data } = parsed;

        switch (type) {
            case "hello": connId = data.id; handleHello(ws, data); break;
            case "ping": send(ws, "pong", { id: MY_ID }); break;
            case "pong": if (connId && peers[connId]) { peers[connId].lastPong = Date.now(); peers[connId].missedPings = 0; } break;
            case "register": handleRegister(ws, data); break;
            case "pulse": handlePulse(ws, data); break;
            case "task-result": handleTaskResult(data); break;
            case "sync-workers": handleSyncWorkers(data); break;
            case "leader-announce": handleLeaderAnnounce(data, connId); break;
        }
    });

    ws.on("close", () => {
        if (connId && peers[connId]) {
            if (leader && leader.id === connId) { leader = null; announceMyself(); }
            delete peers[connId];
        }
    });
});

function handleHello(ws, data) {
    const { id, url } = data;
    peers[id] = { id, url, ws, lastPong: Date.now(), missedPings: 0 };
    
    // Si soy líder, le paso los workers actuales para que el backup esté listo
    const currentWorkers = isLeader() ? Object.values(workers).map(w => ({
        id: w.id, url: w.url, capabilities: w.capabilities, custom_tasks: w.custom_tasks
    })) : [];

    send(ws, "welcome", {
        id: MY_ID,
        leader: leader,
        workers: currentWorkers,
        knownPeers: Object.values(peers).filter(p => p.id !== id).map(p => ({ id: p.id, url: p.url }))
    });
}

function handleWelcome(data) {
    const { knownPeers, leader: theirLeader, workers: syncedWorkers } = data;
    if (syncedWorkers) handleSyncWorkers({ workers: syncedWorkers });
    
    if (Array.isArray(knownPeers)) {
        knownPeers.forEach(p => connectToPeer(p.id, p.url));
    }
    if (theirLeader && (!leader || theirLeader.priority > leader.priority)) {
        leader = theirLeader;
        log(`Líder reconocido: ${leader.id}`);
    }
}

function handleSyncWorkers(data) {
    if (isLeader()) return; 
    data.workers.forEach(w => {
        if (!workers[w.id]) {
            workers[w.id] = { ...w, lastPulse: Date.now(), load: 0 };
            log(`Sincronizado worker: ${w.id}`);
        }
    });
}

// ============================================================
// GESTIÓN DE WORKERS Y TAREAS
// ============================================================
function handleRegister(ws, data) {
    if (!isLeader()) {
        send(ws, "redirect", { leaderId: leader?.id, leaderUrl: leader?.url });
        setTimeout(() => ws.close(), 500);
        return;
    }
    const { id, url, capabilities, custom_tasks } = data;
    workers[id] = { id, url, capabilities, custom_tasks: custom_tasks || [], lastPulse: Date.now(), load: 0, ws };
    log(`Worker registrado: ${id}`);
    send(ws, "registered", { id, leaderId: MY_ID });
    broadcastWorkers();
}

function handlePulse(ws, data) {
    if (!isLeader()) return;
    if (workers[data.id]) {
        workers[data.id].lastPulse = Date.now();
        workers[data.id].load = data.load || 0;
        workers[data.id].ws = ws;
        send(ws, "pulse-ack", { id: data.id });
    }
}

function handleTaskResult(data) {
    const { taskId, status, result, error } = data;
    if (tasks[taskId]) {
        tasks[taskId].status = status;
        tasks[taskId].result = result;
        tasks[taskId].error = error;
        tasks[taskId].completedAt = Date.now();
        log(`Tarea ${taskId} terminada por ${tasks[taskId].workerId}`);
    }
}

function assignTask(capability, payload) {
    if (!isLeader()) return { error: "No soy el líder" };

    const available = Object.values(workers)
        .filter(w => (w.capabilities.includes(capability) || (w.custom_tasks && w.custom_tasks.includes(capability))) && w.ws?.readyState === WebSocket.OPEN)
        .sort((a, b) => a.load - b.load);

    if (available.length === 0) return { error: "No hay workers disponibles" };

    const worker = available[0];
    const taskId = `task-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;

    tasks[taskId] = { taskId, workerId: worker.id, capability, payload, status: "pending", createdAt: Date.now() };
    send(worker.ws, "task-assign", { taskId, type: capability, payload });
    
    return { taskId, workerId: worker.id };
}

// ============================================================
// ELECCIÓN DE LÍDER
// ============================================================
function handleLeaderAnnounce(data, fromId) {
    if (!leader || data.priority > leader.priority) {
        leader = { id: data.leaderId, url: data.leaderUrl, priority: data.priority };
        log(`Nuevo líder: ${leader.id} (Prioridad: ${leader.priority})`);
        propagateLeader(fromId);
    }
}

function propagateLeader(exceptId) {
    Object.values(peers).forEach(p => {
        if (p.id !== exceptId) {
            send(p.ws, "leader-announce", { leaderId: leader.id, leaderUrl: leader.url, priority: leader.priority });
        }
    });
}

function announceMyself() {
    if (!leader || MY_PRIORITY > leader.priority) {
        leader = { id: MY_ID, url: MY_URL, priority: MY_PRIORITY };
        log(`Me proclamo líder (P:${MY_PRIORITY})`);
        propagateLeader();
    }
}

// ============================================================
// TIMERS (Heartbeats)
// ============================================================
setInterval(() => {
    Object.values(peers).forEach(p => {
        if (p.ws?.readyState === WebSocket.OPEN) {
            send(p.ws, "ping", { from: MY_ID });
            p.missedPings = (p.missedPings || 0) + 1;
            if (p.missedPings > PING_RETRIES) {
                log(`Eliminando peer inactivo: ${p.id}`);
                if (leader && p.id === leader.id) { leader = null; announceMyself(); }
                delete peers[p.id];
            }
        }
    });
}, PING_INTERVAL);

setInterval(() => {
    const now = Date.now();
    Object.values(workers).forEach(w => {
        if (now - w.lastPulse > PULSE_TIMEOUT) {
            log(`Worker timeout: ${w.id}`);
            delete workers[w.id];
        }
    });
}, PULSE_CHECK);

setTimeout(announceMyself, 500);

// ============================================================
// API HTTP Y DASHBOARD
// ============================================================
app.get("/status", (req, res) => {
    res.json({
        id: MY_ID, url: MY_URL, isLeader: isLeader(), leader,
        peers: Object.values(peers).map(p => ({ id: p.id, url: p.url, connected: p.ws?.readyState === WebSocket.OPEN })),
        workers: Object.values(workers).map(w => ({ id: w.id, capabilities: w.capabilities, custom_tasks: w.custom_tasks, load: w.load })),
        tasks: Object.values(tasks).sort((a, b) => b.createdAt - a.createdAt).slice(0, 30)
    });
});

app.post("/connect", (req, res) => {
    connectToPeer(req.body.id, req.body.url);
    res.json({ message: "Intentando conectar..." });
});

app.delete("/peers/:id", (req, res) => {
    const p = peers[req.params.id];
    if (p) { if (p.ws) p.ws.close(); delete peers[req.params.id]; res.json({ ok: true }); }
    else res.status(404).send();
});

app.post("/task", (req, res) => res.json(assignTask(req.body.capability, req.body.payload || {})));
app.get("/tasks/:id", (req, res) => res.json(tasks[req.params.id] || { error: "No existe" }));
app.get("/", (req, res) => res.send(getDashboardHTML()));

server.listen(PORT, () => log(`Servidor listo en puerto ${PORT}`));

// ============================================================
// INTERFAZ (HTML/JS)
// ============================================================
function getDashboardHTML() {
    return `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"><title>Coordinator – ${MY_ID}</title>
    <style>
      :root { --bg: #0f172a; --surface: #1e293b; --border: #334155; --text: #e2e8f0; --muted: #64748b; --blue: #38bdf8; --green: #22c55e; --yellow: #f59e0b; --red: #ef4444; }
      body { font-family: 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); padding: 20px; }
      .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(310px, 1fr)); gap: 16px; }
      .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 18px; position: relative; }
      h2 { color: var(--blue); font-size: 14px; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 1px; }
      .item { background: var(--bg); border-radius: 8px; padding: 10px; margin: 6px 0; font-size: 12px; border-left: 3px solid var(--border); position: relative; }
      .online { border-left-color: var(--green); } .leader-item { border-left-color: var(--yellow); }
      .badge { padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: bold; margin-right: 5px; }
      .g { background: #14532d; color: #86efac; } .y { background: #78350f; color: #fde68a; } .r { background: #7f1d1d; color: #fca5a5; }
      input, select, button { width: 100%; padding: 8px; margin: 4px 0; border-radius: 6px; border: 1px solid var(--border); background: var(--bg); color: white; font-size: 12px; }
      button { background: #2563eb; cursor: pointer; border: none; font-weight: bold; transition: 0.2s; }
      button:hover { background: #1d4ed8; }
      .btn-del { position: absolute; right: 8px; top: 8px; width: auto; padding: 2px 6px; background: var(--red); font-size: 9px; }
      .load-bar-wrap { background: var(--border); height: 4px; border-radius: 2px; margin-top: 5px; overflow: hidden; }
      .load-bar { background: var(--green); height: 100%; transition: 0.3s; }
    </style>
</head>
<body>
    <h1 style="text-align:center; color:var(--blue); margin-bottom: 20px;">🌐 Coordinator Dashboard</h1>
    <div id="topStatus" style="display:flex; gap:10px; justify-content:center; margin-bottom:20px;"></div>

    <div class="grid">
        <div class="card"><h2>🏆 Líder Actual</h2><div id="leaderInfo"></div></div>
        
        <div class="card">
            <h2>🔗 Coordinadores (Backups)</h2>
            <div id="peersList" style="max-height:150px; overflow-y:auto;"></div>
            <div style="margin-top:10px">
                <input id="pId" placeholder="ID (coordinator-...)">
                <input id="pUrl" placeholder="URL (wss://...)">
                <button onclick="addP()">Conectar Peer</button>
            </div>
        </div>

        <div class="card"><h2>👷 Workers Activos</h2><div id="workersList"></div></div>

        <div class="card">
            <h2>📋 Asignar Tarea</h2>
            <select id="tCap" onchange="updateFields()">
                <option value="math_compute">math_compute</option>
                <option value="http_fetch">http_fetch</option>
                <option value="search_text">search_text</option>
            </select>
            <div id="tFields"></div>
            <button onclick="sendT()">🚀 Delegar Tarea</button>
            <pre id="tRes" style="font-size:10px; color:var(--muted); margin-top:10px; white-space:pre-wrap;"></pre>
        </div>

        <div class="card" style="grid-column: span 2">
            <h2>📜 Tareas Recientes</h2>
            <div id="taskList" style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;"></div>
        </div>
    </div>

    <script>
        const schemas = { math_compute:['operation','a','b'], http_fetch:['url'], search_text:['text','query'] };
        function updateFields(){
            const f = document.getElementById('tFields'); f.innerHTML = '';
            schemas[document.getElementById('tCap').value].forEach(s => f.innerHTML += \`<input id="f_\${s}" placeholder="\${s}">\`);
        }
        async function addP(){
            await fetch('/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:pId.value, url:pId.value})});
            load();
        }
        async function delP(id){ await fetch('/peers/'+id,{method:'DELETE'}); load(); }
        async function sendT(){
            const cap = document.getElementById('tCap').value; const payload = {};
            schemas[cap].forEach(s => { 
                let v = document.getElementById('f_'+s).value; 
                payload[s] = (s==='a'||s==='b') ? Number(v) : v;
            });
            const r = await fetch('/task',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({capability:cap, payload})});
            const d = await r.json(); document.getElementById('tRes').textContent = JSON.stringify(d,null,2);
            load();
        }
        async function load(){
            const r = await fetch('/status'); const d = await r.json();
            topStatus.innerHTML = \`<span class="badge \${d.isLeader?'g':'y'}">\${d.isLeader?'LÍDER ACTIVO':'MODO BACKUP'}</span> <small>\${d.id}</small>\`;
            leaderInfo.innerHTML = d.leader ? \`<div class="item leader-item"><b>\${d.leader.id}</b><br><small>\${d.leader.url}</small></div>\` : 'Sin líder';
            peersList.innerHTML = d.peers.map(p => \`<div class="item \${p.connected?'online':''}">\${p.id}<button class="btn-del" onclick="delP('\${p.id}')">X</button></div>\`).join('');
            workersList.innerHTML = d.workers.map(w => \`<div class="item online"><b>\${w.id}</b><div class="load-bar-wrap"><div class="load-bar" style="width:\${w.load*100}%"></div></div><small>\${w.capabilities.join(', ')}</small></div>\`).join('');
            taskList.innerHTML = d.tasks.map(t => \`<div class="item"><b>\${t.taskId}</b> <span class="badge \${t.status==='ok'?'g':(t.status==='pending'?'y':'r')}">\${t.status}</span><br><small>\${t.capability}</small><br><span style="color:var(--blue)">Worker: \${t.workerId}</span></div>\`).join('');
        }
        updateFields(); setInterval(load, 3000); load();
    </script>
</body>
</html>`;
}